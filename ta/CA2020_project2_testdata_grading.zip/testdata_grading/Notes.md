- Basic (20%)
- Read hit (10%)
- Write hit (10%)
- Read miss (20%)
    - Detect (10%)
    - Handle (10%)
- Write miss (20%)
    - Detect (10%)
    - Handle (10%)

Final:
1. cold miss + read hit (different indices)
2. read hit, load-use hazard, then write hit (different indices)
2s: rearrange 2. to prevent load-use hazard
3. read from blocks with the same index but different tags to test the 2-way associative cache (no cache replacement)
4. read from blocks with the same index but different tags, including cache replacement. But only load, no write-back involved.
5. read from and write to the blocks with the same index but different tags. (no cache replacement and write back)
6. read and write to the blocks with the same index but different tags. (write back involved)
7. write miss -> write back
