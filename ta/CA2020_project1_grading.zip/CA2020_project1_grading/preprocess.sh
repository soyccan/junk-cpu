#!/bin/bash
# For MacOS only

cd $1/codes;
file=testbench.v
iverilog -o CPU.out *.v ../../supplied/*.v;

lineno=$(grep -n "RegisterInitialization" $file | cut -d: -f 1);
sed -i "" "$lineno a\\
    CPU.Registers.register[24] = -24;
" $file
lineno=$((lineno + 1));
sed -i "" "$lineno a\\
    CPU.Registers.register[25] = -25;
" $file
lineno=$((lineno + 1));
sed -i "" "$lineno a\\
    CPU.Registers.register[26] = -26;
" $file
lineno=$((lineno + 1));
sed -i "" "$lineno a\\
    CPU.Registers.register[27] = -27;
" $file
lineno=$((lineno + 1));
sed -i "" "$lineno a\\
    CPU.Registers.register[28] = 56;
" $file
lineno=$((lineno + 1));
sed -i "" "$lineno a\\
    CPU.Registers.register[29] = 58;
" $file
lineno=$((lineno + 1));
sed -i "" "$lineno a\\
    CPU.Registers.register[30] = 60;
" $file
lineno=$((lineno + 1));
sed -i "" "$lineno a\\
    CPU.Registers.register[31] = 62;
" $file
lineno=$((lineno + 1));


lineno=$(grep -n "D-MemoryInitialization" $file | cut -d: -f 1);
sed -i "" "$lineno a\\
    CPU.Data_Memory.memory[1] = 6;
" $file
lineno=$((lineno + 1));
sed -i "" "$lineno a\\
    CPU.Data_Memory.memory[2] = 10;
" $file
lineno=$((lineno + 1));
sed -i "" "$lineno a\\
    CPU.Data_Memory.memory[3] = 18;
" $file
lineno=$((lineno + 1));
sed -i "" "$lineno a\\
    CPU.Data_Memory.memory[4] = 29;
" $file
lineno=$((lineno + 1));

cd ../../;
