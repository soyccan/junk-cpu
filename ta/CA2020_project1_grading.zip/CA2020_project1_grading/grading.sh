# usage: ./grading.sh <hw_dir>
# Must used after preprocess.sh
# working directory: CA2020_preject1_grading

cd $1/codes;
iverilog -o CPU.out *.v ../../supplied/*.v;

for i in $(seq 1 4); do
    cp ../../testdata/instruction_$i.txt instruction.txt;
    ./CPU.out > /dev/null;
    diff ../../testdata/output_$i.txt ./output.txt > /dev/null;
    if [ $? == 0 ]; then
        echo "Testcase $i passed"
    else
        echo "Testcase $i failed"
    fi
done
cd ../../;
